const Header=()=>{
    return(
        <div className="header-bg">
            <p className="header">
                NoteKeepZen
            </p>
        </div>
    );
}

export default Header;